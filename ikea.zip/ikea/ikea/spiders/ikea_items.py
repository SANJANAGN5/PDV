import scrapy
from ..items import IkeaItem
class IkeaItemsSpider(scrapy.Spider):
    name = "ikea-items"
    allowed_domains = ["www.ikea.com"]
    start_urls = ["https://www.ikea.com/in/en/cat/food-storage-organising-15937/"]

    def parse(self, response):
             
            for product in response.xpath('//div[@class="plp-fragment-wrapper"]'):
                item = IkeaItem()
                item['product_name'] = product.xpath('.//*[@class="notranslate plp-price-module__product-name"]/text()').get()
                item['price'] = product.xpath('.//*[@class="plp-price__sr-text"]/text()').get()
                yield item
            
            next_page = response.xpath('//*[@class="vn__nav vn-8-grid"]/li/a/@href').get()
            if next_page:
               yield response.follow(next_page, callback=self.parse)       